package libs;


import ast.SpaceInvaderVisitor;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

public abstract class Node {

    static protected PrintWriter writer;
    public static void setWriter(String name) throws FileNotFoundException, UnsupportedEncodingException {
        writer = new PrintWriter(name, "UTF-8");
    }
    public static void closeWriter(){
        writer.close();
    }

    //abstract public void evaluate();
    abstract public <C, T> T accept(C context, SpaceInvaderVisitor<C, T> v);


}
