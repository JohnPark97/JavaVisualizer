package eval;

public enum DIRECTION {
    LEFT, RIGHT, UP, DOWN
}
