package eval;

public enum  E_SPRITE {
    ALIEN, BOSS, BONUS
}
