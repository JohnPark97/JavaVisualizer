package ui;

import libs.SimpleTokenizer;
import libs.Tokenizer;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
        List<String> fixedLiterals = Arrays.asList(";", "\n", "(H)", "(M)", "(B)");
        Tokenizer tokenizer = SimpleTokenizer.createSimpleTokenizer("input.tcts",fixedLiterals);
    }

}
