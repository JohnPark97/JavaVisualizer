package libs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SimpleTokenizer implements Tokenizer {

    public static Tokenizer createSimpleTokenizer(String filename, List<String> fixedLiteralsList) {
        return new SimpleTokenizer(filename, fixedLiteralsList);
    }

    private static final String RESERVEDWORD = "_";

    private String inputProgram;
    private List<String> fixedLiterals;
    private String[] tokens;
    private int currentToken = 0;

    private SimpleTokenizer(String filename, List<String> fixedLiteralsList) {
        fixedLiterals = fixedLiteralsList;
        try {
            inputProgram = Files.readString(Paths.get(filename));
        } catch (IOException e) {
            System.out.println("Didn't find file");
            System.exit(0);
        }
        tokenize();
    }

    //modifies: this.tokens
    //effects: will result in a list of tokens (sitting at this.tokens) that has no spaces around tokens.
    private void tokenize() {
        String tokenizedProgram = inputProgram;

        for (String literal : fixedLiterals) {
            tokenizedProgram = tokenizedProgram
                    .replace(literal, RESERVEDWORD + literal + RESERVEDWORD)
                    .replace(RESERVEDWORD + RESERVEDWORD, RESERVEDWORD);
        }

        String[] splitBySep = tokenizedProgram.split("_");

        tokens = splitToken(splitBySep).toArray(new String[0]);

        for (int i = 0; i < tokens.length; i++) {
            tokens[i] = tokens[i].equals("\n") ? tokens[i] : tokens[i].trim();
        }

        System.out.println("FINAL TOKENS: " + Arrays.asList(tokens)); // FOR GRADING: make sure this line gets printed in this format!
    }

    private List<String> splitToken(String[] strings) {
        List<String> tokens = new ArrayList<String>();
        for (String s : strings) {
            if (fixedLiterals.contains(s)) {
                tokens.add(s);
                continue;
            }

            s = s.trim();
            String[] tokenAndRemainder;
            if (s.matches("^\\([HMB]\\).*")) {
                tokenAndRemainder = s.split("(?<=\\))");
            } else if (s.matches("^[a-zA-Z].*")) { // starts with a letter
                tokenAndRemainder = s.split("(?<=\\D)(?=\\d)"); // look for end of letter
            } else if (s.matches("^[\\d].*")) { // starts with a number
                tokenAndRemainder = s.split("(?=\\()(?<=[\\d ])"); // look for end of numbers
            } else {
                throw new RuntimeException("Substring doesn't match any token");
            }
            tokens.add(tokenAndRemainder[0]);
            if (tokenAndRemainder.length > 1) {
                String[] remainder = Arrays.copyOfRange(tokenAndRemainder, 1, tokenAndRemainder.length);
                tokens.addAll(splitToken(new String[]{String.join("", remainder).trim()}));
            }
        }

        return tokens;
    }

    private String checkNext() {
        String token = "";
        if (currentToken < tokens.length) {
            token = tokens[currentToken];
        } else
            token = "NO_MORE_TOKENS";
        return token;
    }

    @Override
    public String getNext() {
        String token = "";
        if (currentToken < tokens.length) {
            token = tokens[currentToken];
            currentToken++;
        } else
            token = "NULLTOKEN";
        return token;
    }


    @Override
    public boolean checkToken(String regexp) {
        String s = checkNext();
        System.out.println("comparing: |" + s + "|  to  |" + regexp + "|");
        return (s.matches(regexp));
    }


    @Override
    public String getAndCheckNext(String regexp) {
        String s = getNext();
        if (!s.matches(regexp)) {
            throw new RuntimeException("Unexpected next token for Parsing! Expected something matching: " + regexp + " but got: " + s);
        }
        System.out.println("matched: " + s + "  to  " + regexp);
        return s;
    }

    @Override
    public boolean moreTokens() {
        return currentToken < tokens.length;
    }

}
